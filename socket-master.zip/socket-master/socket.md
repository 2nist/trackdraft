---
tagline: networking support
---

> **NOTE:** This is just a distribution of luasocket. luasocket is developed [here][luasocket site].

## `local socket = require'socket'`

## Documentation

There's up-to-date luasocket documentation [here][luasocket doc]. Ignore the [official site].

[luasocket doc]:  https://rawgithub.com/diegonehab/luasocket/master/doc/index.html
[official site]:  http://w3.impa.br/~diego/software/luasocket/
[luasocket site]: https://github.com/diegonehab/luasocket
